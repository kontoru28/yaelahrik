# How to run

- install package

```
npm i
```

- run project in development mode

```
npm run dev
```

- build project

```
npm run build
```

u can easily deploying at vercel, after editing the image or text from the web

# Information

Related project <a href="https://github.com/janexmgd/nikahfix-be">nikahfix backend</>
